# ResizeToFillTemplate  
Unity WebGL template that scales to the entire browser/container window. Just 50 lines, has loading progress bar.  
  
Copy WebGLTemplates into the Assets folder, select it in PlayerSettings and done.
